import rom_config as rom
rom.mame_fullname = "Game"
rom.ADD_TIME_HOUR_MSB=36
rom.ADD_TIME_HOUR_LSB=37
rom.ADD_TIME_MIN_MSB=38
rom.ADD_TIME_MIN_LSB=39
rom.ADD_TIME_SEC_MSB=40
rom.ADD_TIME_SEC_LSB=41
rom.ADD_TIME_HOUR_MSB_PM_VALUE=2
rom.flag_lcd_deflicker_level = 1
K1 = rom.BTN_UP
K2 = rom.BTN_DOWN
K3 = 0
K4 = 0
rom.BTN_DATA[rom.R2] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)
K1 = rom.BTN_RIGHT + rom.BTN_DOWN
K2 = rom.BTN_RIGHT + rom.BTN_UP
K3 = rom.BTN_LEFT + rom.BTN_DOWN
K4 = rom.BTN_LEFT + rom.BTN_UP
rom.BTN_DATA[rom.R3] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)

K1 = rom.BTN_B + rom.BTN_TIME
K2 = rom.BTN_TIME
K3 = rom.BTN_GAME
K4 = rom.BTN_B + rom.BTN_GAME
rom.BTN_DATA[rom.R4] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)
