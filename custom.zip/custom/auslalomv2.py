import rom_config as rom
rom.mame_fullname = "Avtoslalom (Versiya 2)"

# Autoslalom (Versiya 2) / Elektronika SM5A clock RAM layout.
# This is the same 0x740-byte Elektronika family layout used by nupogodi.
rom.ADD_TIME_HOUR_MSB = 36
rom.ADD_TIME_HOUR_LSB = 37
rom.ADD_TIME_MIN_MSB = 38
rom.ADD_TIME_MIN_LSB = 39
rom.ADD_TIME_SEC_MSB = 40
rom.ADD_TIME_SEC_LSB = 41
rom.ADD_TIME_HOUR_MSB_PM_VALUE = 0

# Exact equivalent of the auslalom MAME input table.  The custom format
# stores each R-port mask as four little-endian button bytes.
K1 = 0
K2 = 0
K3 = 0
K4 = 0
rom.BTN_DATA[rom.R2] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)
K1 = rom.BTN_RIGHT + rom.BTN_A
K2 = rom.BTN_B
K3 = rom.BTN_LEFT
K4 = rom.BTN_UP
rom.BTN_DATA[rom.R3] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)
# Working console-compatible R4 mapping used by the known-good ROMs:
# physical START/SELECT remain distinguishable in Retro-Go.
K1 = rom.BTN_B + rom.BTN_TIME
K2 = rom.BTN_TIME
K3 = rom.BTN_GAME
K4 = rom.BTN_B + rom.BTN_GAME
rom.BTN_DATA[rom.R4] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)
rom.BTN_DATA[rom.BA] = 0

rom.BTN_DATA[rom.B] = 0
rom.flag_lcd_deflicker_level = 1
