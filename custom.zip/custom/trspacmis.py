import rom_config as rom
rom.mame_fullname = "Space Mission"
# Space Mission uses the gnw_fire ROM layout.
rom.ADD_TIME_HOUR_MSB=28
rom.ADD_TIME_HOUR_LSB=29
rom.ADD_TIME_MIN_MSB=30
rom.ADD_TIME_MIN_LSB=31
rom.ADD_TIME_SEC_MSB=0
rom.ADD_TIME_SEC_LSB=1
rom.ADD_TIME_HOUR_MSB_PM_VALUE=2
rom.flag_lcd_deflicker_level = 2
# R2/R3 come from the exact gnw_fire MAME input profile.
rom.BTN_DATA[rom.R2] = 0
rom.BTN_DATA[rom.R3] = 0
K1 = rom.BTN_B + rom.BTN_TIME
K2 = rom.BTN_TIME
K3 = rom.BTN_GAME
K4 = rom.BTN_B + rom.BTN_GAME
rom.BTN_DATA[rom.R4] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)
rom.BTN_DATA[rom.BA] = rom.BTN_RIGHT + rom.BTN_A
rom.BTN_DATA[rom.B] = rom.BTN_LEFT
