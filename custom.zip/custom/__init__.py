
rom.flag_lcd_deflicker_level = 1
