import rom_config as rom
rom.mame_fullname = "Tayny okeana"
# Tayny okeana uses the gnw_octopus ROM layout.
rom.ADD_TIME_HOUR_MSB = 54
rom.ADD_TIME_HOUR_LSB = 55
rom.ADD_TIME_MIN_MSB = 56
rom.ADD_TIME_MIN_LSB = 57
rom.ADD_TIME_SEC_MSB = 58
rom.ADD_TIME_SEC_LSB = 59
rom.ADD_TIME_HOUR_MSB_PM_VALUE = 8
rom.flag_lcd_deflicker_level = 2
rom.BTN_DATA[rom.R2] = 0
rom.BTN_DATA[rom.R3] = 0
K1 = rom.BTN_B + rom.BTN_TIME
K2 = rom.BTN_TIME
K3 = rom.BTN_GAME
K4 = rom.BTN_B + rom.BTN_GAME
rom.BTN_DATA[rom.R4] = K1 | (K2 << 8) | (K3 << 16) | (K4 << 24)
rom.BTN_DATA[rom.BA] = rom.BTN_LEFT
rom.BTN_DATA[rom.B] = rom.BTN_RIGHT + rom.BTN_A
